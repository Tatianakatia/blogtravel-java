package com.example.travelblog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelBlogApplicationTests {

	@Test
	void contextLoads() {
	}

}
