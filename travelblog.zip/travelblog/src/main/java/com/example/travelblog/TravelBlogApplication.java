package com.example.travelblog;

import com.example.travelblog.domain.User;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelBlogApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelBlogApplication.class, args);

	}

}
