package com.example.travelblog.domain;

public class Post_Category {
}
